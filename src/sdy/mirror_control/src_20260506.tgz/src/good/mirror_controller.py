
import asyncio, time
from multiprocessing import Process, Event
from multiprocessing.shared_memory import SharedMemory
#from multiprocessing.managers import SharedMemoryManager
from dataclasses import dataclass
import numpy as np

from config import (TOTAL_BUFF_BYTES, MIRRORS_COUNT, ACTUATORS_PER_MIRROR, SHM_NAME, SENSORS_PER_AMP, CAPACITY_SENSORS, )
from sensor_collector import collector
import utils



@dataclass(frozen=True)
class MirrorsConfig:
    control_period_s:float = 1.0
    sensor_period_s:float = 0.05
    min_steps:int = 50
    max_steps:int = 500
    command_jitter_std = 0.1


def my_func(aaa):
    while True:
        print(f"SubProcess: {aaa}")
        time.sleep(2)

class Mirrors:
    """子镜面形闭环控制类"""

    def __init__(self, debug=False):
        self.logger = utils.OCS_Logger(name="MIRRORS", debug=debug)
        utils.silence_loggers(['gsv',])     # 防止gsv86lib驱动DEBUG日志刷屏

        # 控制标签
        self.stop_event = Event()
        self.close_loop = False


        # 闭环矩阵
        self.Target = np.zeros((MIRRORS_COUNT, ACTUATORS_PER_MIRROR))       # 力维持目标值，由上层提供(主动光学/查表)
        self.Force = np.zeros((MIRRORS_COUNT, ACTUATORS_PER_MIRROR))        # 力传感器数据
        self.Force_TS = np.zeros((MIRRORS_COUNT, ACTUATORS_PER_MIRROR))     # 力传感器时间戳
        self.Error = np.zeros((MIRRORS_COUNT, ACTUATORS_PER_MIRROR))
        self.K_p = np.loadtxt("settings/Coefficient_K_p.csv", delimiter=',', skiprows=1)    # 增益
        self.Threshold = np.loadtxt("settings/Threshold.csv", delimiter=',', skiprows=1)    # 阈值

        #self.Available = np.full((MIRRORS_COUNT, ACTUATORS_PER_MIRROR), False, dtype=bool)
        #self._mask_blocked("settings/Blocked.csv")
        self.Available = np.full((MIRRORS_COUNT, ACTUATORS_PER_MIRROR), False, dtype=bool)
        self.Available[0, 0] = True
        self.Available[0, 1] = True
        

        # 映射索引
        mapping = np.loadtxt("settings/Actuator_Mapping.csv", delimiter=',', skiprows=1, dtype=int)
        actuator_id, controller_id, axis_id, amplifer_id, channel_id = mapping.T    # 配置表拆成5个列向量
        self._sensor_idx = amplifer_id*SENSORS_PER_AMP + channel_id                  # 逻辑促动器空间到物理传感器空间的映射

        # 共享内存
        self.shm = SharedMemory(create=True, name=SHM_NAME, size=TOTAL_BUFF_BYTES)
        self._buffer = np.ndarray((CAPACITY_SENSORS*2,), dtype=np.float64, buffer=self.shm.buf)
        self._buffer.fill(0.0)
        self._data =  self._buffer[:CAPACITY_SENSORS]       # 传感器数据视图，零拷贝
        self._timestamp = self._buffer[CAPACITY_SENSORS:]   # 传感器时间戳视图，零拷贝


        # 控制器
        #self.Controllers = [Controller() for  in ]

        # 传感器
        self.start_time = time.monotonic()+3.0
        self.Amplifiers = []
        for amp_id in range(1):
            worker = Process(
                    #target=my_func,
                    #args=(amp_id,),
                    target=collector,
                    args=('/dev/ttyr00', amp_id, SHM_NAME, self.stop_event, self.start_time,),
                    kwargs={"debug":debug, },
            )
            worker.start()
            self.Amplifiers.append(worker)
    
    def __del__(self):
        self.close()
        for worker in self.Amplifiers:
            worker.join()

    def close(self):
        if self.stop_event and not self.stop_event.is_set():
            self.stop_event.set()
        for worker in self.Amplifiers:
            worker.join(timeout=2.0)
        if hasattr(self, '_buffer'):
            del self._data
            del self._timestamp
            del self._buffer
        if self.shm:
            self.shm.close()
            self.shm.unlink()
            self.shm = None
        #utils.stop_log_listener()


    def _mask_blocked(self, path):
        """处理屏蔽力促动器单元"""
        try:
            blocked = np.loadtxt(path, delimiter=',', comments='#', skiprows=1, dtype=int)
        except OSError:
            return      # 没有Blocked.csv文件
        if blocked.size == 0:
            return  # Blocked.csv文件为空记录
        if blocked.ndim == 1:
            blocked = blocked.reshape(1, -1)    # Blocked.csv文件中只有一行记录
        if blocked.shape[1] != 2:
            raise ValueError("Blocked.csv 格式错误，应为两列：mirror_id, actuator_id")
        rows, cols = blocked.T  #blocked[:, 0], blocked[:, 1]
        self.Available[rows, cols] = False




    def get_force(self):
        """获取最新力传感器数据和时间戳 -- 花式索引，一次拷贝，1.17us"""
        self.Force = self._data[self._sensor_idx].reshape(MIRRORS_COUNT, ACTUATORS_PER_MIRROR)
        self.Force_TS = self._timestamp[self._sensor_idx].reshape(MIRRORS_COUNT, ACTUATORS_PER_MIRROR)
        return self.Force, self.Force_TS

    def run(self):
        try:
            while True:
                time.sleep(2)
                self.get_force()
                self.logger.info(f"{self.Force[self.Available]}, {self.Force_TS[self.Available]}")
        except KeyboardInterrupt:
            pass

    def build_motor_commands(self):
        comamnds = []
        for ctrl_id in range(MIRRORS_COUNT):
            axes = np.nonzero(self.Steps[c])[0]
            if len(axes) == 0:
                continue
            parts = [f"#{a:02d}J={self.Steps[ctrl_id, axis_id]:0.3f}" for axis_id in axes]
            cmd = " ".join(parts)
            comamnds.append((ctrl_id, cmd))
        return commands

    async def execute_commands(self):
        commands = self.build_motor_commands()
        if not commands:
            return
        tasks = []
        for ctrl_id, cmd in commands:
            tasks.append(asyncio.create_task(self.Controllers[ctrl_id].execute_command(cmd)))
        await asyncio.wait_for(asyncio.gather(*tasks), timeout=2.0)



        

    """
        active_mask = np.ones((6, 25), dtype=bool)
        active_mask[bad_sensor_pos] = False

        Gain_matrix = np.full((6, 25), default_gain)
        Gain_matrix[centrain_actuators] = custom_gain

        # P control
        Error = Target - Measured
        maks = (np.abs(Error) > Threshold) & active_mask
        Steps = Error[mask] * Gain_matrix[mask]

        # PI control
        dt = 2.0
        Error = Target - Measured
        I_error += Error * dt
        I_error = np.clip(I_error, I_post_max, I_minus_max)
        Steps_raw = Error*Gain_matrix + Ki*I_error
        Steps = np.clip(Steps_raw, min_steps, max_steps)






        tasks = []
        for ctrl_id, axis in zip(np.where(np.abs(Error)>Threshold)[0]:
            task = asyncio.create_task(self.move_motor(ctrl_id, axis))
            tasks.append(task)
        await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=True), timeout=2.0)




        # 共享内存
        self.shm = SharedMemory(create=True, name=SHM_NAME, size=TOTAL_BUFF_BYTES)
        self.buffer = np.ndarray((CAPCITY_SENSORS,), dtype=np.float64, buffer=self.shm.buf)
        self.buffer.fill(0.0)

        # 多进程采集
        self.stop_event = Event()
        self.workers = []
        for amp_id in xxx:
            worker = mp.Process(
                    target=collector,
                    args=(path, amp_id, shm_name, stop_event, start_time,),
            )
            worker.start()
            self.workers.append(worker)

    def close(self):
        if self.shm:
            self.shm.close()
            self.shm.unlink()
            self.shm = None
        if not self.stop_event.is_set():
            self.stop_event.set()
            self.stop_event = None
    """



if __name__ == "__main__":
    import logging, atexit
    logging.raiseExceptions=False
    atexit.register(utils.stop_log_listener)


    mirrors = Mirrors()
    try:
        mirrors.run()
    except KeyboardInterrupt:
        mirrors.close()
        time.sleep(2)


