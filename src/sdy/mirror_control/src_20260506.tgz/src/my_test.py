
import time
#from amplifier import Amplifier

#amp = Amplifier("/dev/ttyr00", 0, 2.0)
#time.sleep(1)
#for _ in range(10):
#    res = amp.read_data()
#    print(res)
#    time.sleep(1)


from gsv86lib import gsv86

com = gsv86("/dev/ttyr00", 115200)
com.writeDataRate(10.0)
#com.StartTransmission()

while True:
    rawdata = com.ReadValue()
    print(rawdata.data)
    time.sleep(2)


